def func(x,a,b,c):
    return a*x*x + b*x + c

f_coef = []
g_coef = []

x = int(input())

f = input()
for i in f.split():
    f_coef.append(int(i))

g = input()
for i in g.split():
    g_coef.append(int(i))

f_res = func(x, f_coef[0], f_coef[1], f_coef[2])
g_res = func(f_res, g_coef[0], g_coef[1], g_coef[2])

print(g_res)
