def larger(a,b):
    if a>b: return a
    else: return b

def count_divisor(n):
    cnt = 0
    for i in range(1, n+1):
        if n%i==0: cnt = cnt + 1
    return cnt

flag = cnt = 0
while True:
    n= int(input())
    if n<0: break

    cnt_divisor = count_divisor(n)

    if cnt_divisor == 2:
        flag = 1
        if not cnt: max_prime = n
        else: max_prime = larger(max_prime, n)
    cnt = 1

if not flag: print("none")
else: print("%d" % max_prime)
