def fac(n):
    fac = 1
    for i in range(1, n+1):
        fac *= i
    return fac

def comb(x,y):
    comb = fac(x) // (fac(y)*fac(x-y))

    return comb

n1 = int(input())
n2 = int(input())

print(comb(n1, n2))
