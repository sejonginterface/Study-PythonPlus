def is_prime(x):
    for i in range(2, x):
        if x%i == 0: break

    if i==x-1: return 1
    return 0

def next_prime(x):
    i = x+1
    while True:
        if is_prime(i): break
        i = i+1
    return i

n, m = input().split()
n = int(n)
m = int(m)

for i in range(1, m+1):
    n = next_prime(n)
    print(" %d" % n, end = '')
