def isLeapYear(year):
    if year%4 == 0:
        if year%100 == 0:
            if year%400 == 0:
                return 1
            return 0
        return 1
    return 0

def getTotalNumberOfLeapYear(startYear, endYear):
    cnt_LYear = 0
    for i in range(startYear, endYear+1):
        if isLeapYear(i):
            cnt_LYear = cnt_LYear + 1
    return cnt_LYear

startYear, endYear = input().split()
startYear = int(startYear)
endYear = int(endYear)

print(getTotalNumberOfLeapYear(startYear, endYear))
