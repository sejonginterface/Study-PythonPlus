N = 0
def die1(x):
    for i in range(1,7):
        die2(x,i)
        
def die2(x,y):
    for i in range(1,7):
        die3(x,y,i)

def die3(x,y,z):
    if x+y+z == N:
        print("%d %d %d" % (x,y,z))

N = int(input())
for i in range(1,7):
    die1(i)
