def fac(n):
    fac = 1
    for i in range(1, n+1):
        fac *= i
    return fac

def comb(x,y):
    comb = fac(x) // (fac(y)*fac(x-y))

    return comb

def pascal_triangle(col):
    num = col*4 - 1

    for i in range(1, col+2):
        for j in range(1, num+1):
            print(end = ' ')
        num -= 2

        j=1
        for j in range(1, i):
            print("%d   "% comb(i-1, j-1), end = '')
        print(comb(i-1, j))

col = int(input())
pascal_triangle(col)
