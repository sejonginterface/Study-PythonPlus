def is_palindrome(n):
    arr = [0] * 10
    flag = num = 0

    while n!=0:
        arr[num] = n%10
        n = n // 10
        num=num+1

    i=0
    j=num-1
    while i<=j:
        if arr[i] != arr[j]:
            flag = 1
            break
        i = i+1
        j = j-1

    if flag: return 0
    return 1

sum = 0
n = int(input())
flag = is_palindrome(n)

while n!=0:
    sum += n%10
    n//=10

if flag: print("%d\nYes" % sum)
else: print("%d\nNo" % sum)
