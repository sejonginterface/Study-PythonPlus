def fac(n):
    fac = 1
    for i in range(1, n+1):
        fac *= i
    return fac

n = int(input())
print(fac(n))
