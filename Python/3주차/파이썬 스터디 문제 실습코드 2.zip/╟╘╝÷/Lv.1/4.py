def factor(n):
    for i in range(1, n+1):
        if n%i == 0:
            print(" %d" % i, end = '')
    print('')

while True:
    n = int(input())
    if n<=0: break

    factor(n)
