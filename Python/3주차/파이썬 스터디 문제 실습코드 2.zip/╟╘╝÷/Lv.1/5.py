def f1(x,y):
    if x==1:
        print("Americano")
        y -= 500
    elif x==2:
        print("Cafe Latte")
        y-=400
    else:
        print("Lemon Tea")
        y-=300

    return y

def f2(x):
    num_500 = x//500
    print(num_500, end = ' ')

    return x - num_500*500

def f3(x):
    print(x//100, end = '')

n = int(input())
m = int(input())

change = f1(n,m)
change = f2(change)
f3(change)
