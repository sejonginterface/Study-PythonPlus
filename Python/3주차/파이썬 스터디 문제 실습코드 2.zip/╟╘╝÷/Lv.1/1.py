def sum(n):
    return n*(n+1)/2

a,b = input().split()
a = int(a)
b = int(b)

res = int(sum(b)) - int(sum(a-1))
print(res)
