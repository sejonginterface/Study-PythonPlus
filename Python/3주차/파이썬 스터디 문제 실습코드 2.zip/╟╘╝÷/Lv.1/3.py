def ceiling(x):
    if x-int(x) == 0:
        return int(x)
    else:
        return int(x+1)

f = float(input())
print(ceiling(f))
