def func(x,a,b,c):
    return a*x*x + b*x + c

coef = []
x = int(input())
num = input()
for i in num.split():
    coef.append(int(i))

res = func(x,coef[0], coef[1], coef[2])
print(res)
    
