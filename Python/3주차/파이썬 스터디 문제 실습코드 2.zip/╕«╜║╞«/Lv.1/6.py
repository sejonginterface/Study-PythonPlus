x = []
e = [0] * 10
o = [0] * 10

n = int(input())
num = input()

for i in num.split():
    x.append(int(i))

idxev = idxod = 0
for i in range(0,n):
    if x[i]%2 == 0:
        e[idxev] = x[i]
        idxev = idxev + 1
    else:
        o[idxod] = x[i]
        idxod = idxod + 1

print("Even:")
if idxev>0:
    for i in range(0, idxev):
        print(e[i])
else:
    print("none")

print("Odd:")
if idxod>0:
    for i in range(0, idxod):
        print(o[i])
else:
    print("none")
