arr = []

n = int(input())
num = input()
k = 1
for i in num.split():
    arr.append(int(i))
    k *= 10

num = 0
for i in range(0,n):
    k //= 10
    if arr[i] == 0: continue
    num += arr[i] * k

print(num)
