arr = []
cnt = [0,0,0]

num = input()
for i in num.split():
    i = int(i)
    arr.append(i)

for i in range(0,10):
    if arr[i] == 1: cnt[0] = cnt[0] + 1
    elif arr[i] == 2: cnt[1] = cnt[1] + 1
    else: cnt[2] = cnt[2] + 1

for i in range(0,3):
    print("%d" % (i+1), end = ':')
    for j in range(0,cnt[i]):
        print("*", end = '')
    print('')
