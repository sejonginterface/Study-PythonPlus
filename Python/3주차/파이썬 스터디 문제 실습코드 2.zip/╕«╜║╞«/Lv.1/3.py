arr = []

num = input()
for i in num.split():
    i = int(i)
    arr.append(i)

max = arr[0]
for i in range(1,10):
    if max < arr[i]: max = arr[i]

print(max)
