arr = []

num = input()
for i in num.split():
    i = int(i)
    arr.append(i)

if arr[0]>arr[1]:
    max = arr[0]
    second = arr[1]

else:
    max = arr[1]
    second = arr[0]

for i in range(2, 5):
    if arr[i] > max:
        second = max
        max = arr[i]

    elif arr[i] > second:
        second = arr[i]

print(max, second)
