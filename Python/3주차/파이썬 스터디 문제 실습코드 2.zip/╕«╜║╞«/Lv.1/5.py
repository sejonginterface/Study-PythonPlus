arr = []
sum = []

n = int(input())
num = input()
for i in num.split():
    i = int(i)
    arr.append(i)
    sum.append(0)

for i in range(0,n):
    for j in range(0,i+1):
        sum[i] += arr[j]

for i in range(0,n):
    print(sum[i], end = ' ')
