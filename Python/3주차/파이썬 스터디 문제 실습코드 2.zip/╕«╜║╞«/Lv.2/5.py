c = []
mo = ['a', 'e', 'i', 'o', 'u']

for i in range(0,10):
    ci = input()
    c.append(ci)

for i in range(0,8):
    flag = 0
    for j in range(0,5):
        if c[i] == mo[j]: flag = 1
        if c[i+2] == mo[j]: flag = 1

    for j in range(0,5):
        if c[i+1] == mo[j]: break

    if j==5: flag = 1

    if not flag:
        for j in range(0,3):
            print(c[i+j], end = '')
        print('')
