str = []

for i in range(0,5):
    c = input()
    str.append(c)

for i in range(0,5):
    for j in range(0,5):
        print(str[j], end = '')
    print('')

    tmp = str[4]
    for j in range(4, 0, -1):
        str[j] = str[j-1]
    str[0] = tmp
