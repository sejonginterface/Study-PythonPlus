arr = []

n = int(input())
num = input()

for i in num.split():
    arr.append(int(i))

while True:
    sum = 0
    a,b = input().split()
    a = int(a)
    b = int(b)

    if a==0 and b==0: break

    if a>b:
        tmp = a
        a = b
        b = tmp

    for i in range(a, b+1):
        sum += arr[i]

    print(sum)
