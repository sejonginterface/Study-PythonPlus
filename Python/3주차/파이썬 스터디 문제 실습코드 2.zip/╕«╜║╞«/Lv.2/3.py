arr = []

num = input()
for i in num.split():
    i = int(i)
    arr.append(i)

for i in range(0,10):
    flag = 0
    for j in range(0,i):
        if arr[i] == arr[j]: flag = 1

    if not flag:
        print(" %d" % arr[i], end = '')
