arr = []

n = int(input())
num = input()

for i in num.split():
    arr.append(int(i))

for i in range(0,n):
    sum = 0
    for j in range(i, n):
        sum += arr[j]
        if (i==0 and j==i) or sum > max:
            max = sum

print(max)
