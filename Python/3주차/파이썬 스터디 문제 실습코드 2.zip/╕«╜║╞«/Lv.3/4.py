digit = []

n = int(input())
i = 0

while n!=0:
    digit.append(n%10)
    n = n//10
    i = i+1

num_of_digit = i
same_flag = 0

for i in range(0,num_of_digit):
    same_count = 1
    for j in range(0, num_of_digit):
        if i==j: continue
        if digit[i] == digit[j]:
            same_count = same_count + 1
            same_flag = 1

    if i==0 or same_count>max_same_count:
        max_same = digit[i]
        max_same_count = same_count

if same_flag == 1:
    print("YES")
    print(max_same, max_same_count)

else:
    print("NO")
    for i in range(0,num_of_digit):
        print(digit[i], end = ' ')
