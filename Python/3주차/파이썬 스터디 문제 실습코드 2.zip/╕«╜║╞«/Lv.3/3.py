seat = []

n = int(input())
num = input()
for i in num.split():
    seat.append(int(i))

want = int(input())
for i in range(0, n-want+1):
    for j in range(0,want):
        if seat[i+j] == 0: flag = 1
        else:
            flag = 0
            break

    if flag:
        for j in range(0, want):
            print(i+j+1, end = ' ')
        break

cnt = 0
if not flag:
    print("none")
    for i in range(0,n):
        if seat[i] == 0: cnt = cnt + 1
    print(cnt)
