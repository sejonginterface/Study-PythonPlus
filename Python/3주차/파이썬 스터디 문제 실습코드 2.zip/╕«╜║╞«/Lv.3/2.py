arr = []

i = 0
while True:
    avg = sum = 0
    avg_min = avg_max = avg_eq = 0

    n = int(input())
    if n<0: break
    arr.append(n)

    for j in range(0, i+1):
        sum += arr[j]
    avg = sum//(i+1)

    for j in range(0,i+1):
        if arr[j] == avg: avg_eq = avg_eq + 1
        elif arr[j] > avg: avg_max = avg_max + 1
        else: avg_min = avg_min + 1

    print("%d %d %d" % (avg_max, avg_min, avg_eq))
    i = i + 1
