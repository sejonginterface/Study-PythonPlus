cnt = num = 0

n = int(input())

while n!=0:
    num = num*10 + n%10
    n = int(n/10)

for i in range(1, num+1):
    if num % i == 0:
        cnt = cnt+1

print(num, cnt)
