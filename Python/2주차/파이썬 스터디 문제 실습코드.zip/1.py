kor, math, eng = input().split()

kor = int(kor)
math = int(math)
eng = int(math)

sum = kor*0.2 + math*0.3 + eng*0.5

print("%.2f" % sum)
