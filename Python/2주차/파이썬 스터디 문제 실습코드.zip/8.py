n, m = input().split()
n = int(n)
m = int(m)

for i in range(n, m+1):
    fibo = fib1 = 0
    fib2 = 1

    for j in range(1, i+1):
        fib1 = fib2
        fib2 = fibo
        fibo = fib1 + fib2

    print("F(%d)=%d+%d=%d" % (i, fib1, fib2, fibo))
