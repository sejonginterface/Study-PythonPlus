cnt = cnt2 = 0

while True:
    n = int(input())
    if n<0: break

    cnt = cnt+1
    if n>=1 and n<=100:
        cnt2 = cnt2+1

print(cnt, cnt2)
