i = 0

while True:
    n = int(input())
    if n<0: break

    sum = 0
    while n!=0:
        sum = sum+n%10
        n = int(n/10)

    if i==0 or sum<min:
        min = sum
    i = i+1

print(min)
