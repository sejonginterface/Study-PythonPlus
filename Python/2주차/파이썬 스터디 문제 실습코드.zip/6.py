c = input()

if c>='A' and c<='Z':
    print("upper")
elif c>='a' and c<='z':
    print("lower")
elif c>='0' and c<='9':
    print("number")
else:
    print("etc")
