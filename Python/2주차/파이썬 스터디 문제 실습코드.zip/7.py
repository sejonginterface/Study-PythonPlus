sum = sum20 = sum30 = 0
cnt = cnt20 = cnt30 = 0
flag = 0

while True:
    n = int(input())
    if n<0: break

    sum = sum + n

    if not flag:
        if sum>20:
            sum20 = sum-n
            cnt20 = cnt
            flag = 1
            
    elif flag == 1:
        if sum>30:
            sum30 = sum-n
            cnt30 = cnt
            flag = 2

    cnt = cnt+1

print(sum20, cnt20)
print(sum30, cnt30)
    
